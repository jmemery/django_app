from django.http import  HttpResponse
from django.shortcuts import render

def home(request):
    return render(request, 'home.html')
def testimonials(request):
    return render(request, 'testimonials.html')
def projects(request):
    return render(request, 'projects.html')
def about(request):
    return render(request, 'about.html')
